package eu.raspberrymods.fishlib;

import net.fabricmc.api.ClientModInitializer;

public class FishLibClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}